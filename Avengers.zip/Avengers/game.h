#ifndef GAME_H
#define GAME_H
#include "battle.h"
#include <fstream>

class game
{
public:
    game(int aantalGames, char naam[]);
    std::string bosskeuze(ruben::warrior& speler);
};

#endif // GAME_H
