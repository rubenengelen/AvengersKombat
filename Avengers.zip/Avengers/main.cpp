#include "game.h"

int main(int argc, char *argv[])
{
    game(atoi(argv[2]), argv[1]);
    return 0;
}
